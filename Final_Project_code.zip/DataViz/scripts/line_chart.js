// Defines a class named LineChart
class LineChart {

    //constructor method for initialising the class
    constructor(container, width, height, margin, donutChartInstance) {
        //assigns the provided values to class properties
        this.container = container;
        this.width = width;
        this.height = height;
        this.margin = margin;
        this.donutChart = donutChartInstance;

    }

    //method to initialise the line chart with provided data, title, x-axis label, and y-axis label
    InitialiseChart(data, chartTitle, xLabel, yLabel) {
        //determines the domain for x-axis and y-axis
        const xDomain = d3.extent(data, d => d.month);
        const yDomain = [0, d3.max(data, d => d.sun)];

        //array of month names for labeling the x-axis
        const monthNames = [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];

        //creates an SVG element with specified dimensions and a border
        this.svg = d3
            .select(this.container)
            .append('svg')
            .attr('width', this.width)
            .attr('height', this.height)
            .style('border', '2px solid #000');

        // Add chart title
        this.svg.append('text')
            .attr('class', 'chart-title')
            .attr('x', this.width / 2)
            .attr('y', this.margin.top / 2) // Adjust this to change the space above the title     
            .text(chartTitle);


        // Calculate inner dimensions
        this.innerWidth = this.width - this.margin.left - this.margin.right;
        this.innerHeight = this.height - this.margin.top - this.margin.bottom;

        //sets up x and y scales for the chart
        this.xScale = d3.scaleLinear().domain(xDomain).range([0, this.innerWidth]);
        this.yScale = d3.scaleLinear().domain(yDomain).range([this.innerHeight, 0]);


        //defines the line function for the chart (Updated to use sun data)
        this.line = d3
            .line()
            .x(d => this.xScale(d.month))
            .y(d => this.yScale(d.sun))
            .curve(d3.curveLinear);

        //appends a group element to contain the chart elements
        this.lineWrapper = this.svg
            .append('g')
            .attr('transform', `translate(${this.margin.left}, ${this.margin.top})`)
            .attr('class', 'chart-border'); 

        //adds x-axis and labels
        this.lineWrapper
            .append('g')
            .attr('class', 'x-axis')
            .attr('transform', `translate(0, ${this.innerHeight})`)
            .call(d3.axisBottom(this.xScale)
                .tickFormat((d) => monthNames[d - 1])
            );

        
            

        


        // Append a Y-axis to the line chart
        this.lineWrapper
            .append('g')
            .attr('class', 'y-axis')
            .call(d3.axisLeft(this.yScale));

        // Move the text of the Y-axis to the left
        this.lineWrapper.selectAll('.y-axis text')
            .attr('transform', 'translate(-5,0)');

        // Add x-axis label
        this.svg.append('text')
            .attr('class', 'x-label')
            .attr('x', this.width / 2 + 10)
            .attr('y', this.height-10)
            .attr('text-anchor', 'middle')
            .text(xLabel);

        // Add y-axis label
        this.svg.append('text')
            .attr('class', 'y-label')
            .attr('transform', `rotate(-90)`)
            .attr('x', -this.height / 2)
            .attr('y', this.margin.left / 4)
            .attr('text-anchor', 'middle')
            .text(yLabel);


        //sets up a tooltip for data points
        this.tooltip = d3
            .select(this.container)
            .append('div')
            .attr('class', 'tooltip')
            .style('opacity', 0);

        //adds a cursor line for highlighting data points
        this.cursorLine = this.lineWrapper.append('line')
            .attr('class', 'cursor-line')
            .attr('x1', 0)
            .attr('x2', 0)
            .attr('y1', 0)
            .attr('y2', this.height)
            .style('stroke', '#ccc')
            .style('stroke-dasharray', '2');

        //adds a label for cursor tooltip
        this.cursorLabel = this.svg.append('text')
            .attr('class', 'cursor-label')
            .attr('text-anchor', 'middle')
            .attr('x', 0)
            .attr('y', 0)

        // Set up an event listener for mousemove on the SVG element
        this.svg.on('mousemove', event => {
            // Extract the x-coordinate of the mouse pointer
            const [x] = d3.pointer(event);

            // Convert the x-coordinate to the corresponding data value on the X-axis
            const xValue = this.xScale.invert(x - this.margin.left);

            // Use bisect to find the index of the nearest data point to the current mouse position
            const bisect = d3.bisector(d => d.month).left;
            const index = bisect(data, xValue, 1);

            // Get the two nearest data points for interpolation
            const d0 = data[index - 1];
            const d1 = data[index];

            // Determine the interpolated value based on the closer data point
            const interpolatedValue = xValue - d0.month > d1.month - xValue ? d1 : d0;
            const yValue = interpolatedValue.sun; // Extract the sun value
            const monthName = monthNames[Math.round(interpolatedValue.month) - 1]; // Get the corresponding month name

            // Update the cursor line to follow the mouse position along the X-axis
            this.cursorLine
                .attr('x1', this.xScale(interpolatedValue.month))
                .attr('x2', this.xScale(interpolatedValue.month))
                .attr('y1', 0)
                .attr('y2', this.height);

            // Display a tooltip with information about the data point at the mouse position
            this.tooltip
                .html(`Month: ${monthName}, Sun: ${yValue.toFixed(2)} hours`)
                .style('left', event.pageX + 10 + 'px')
                .style('top', event.pageY - 50 + 'px')
                .style('opacity', 0.9); 
        });


        //listens for mouse leaving the chart area
        this.svg.on('mouseout', () => {
            this.tooltip.style('opacity', 0);
            this.cursorLine.attr('x1', 0).attr('x2', 0);
            this.cursorLabel.attr('x', 0).attr('y', 0);
        });
    }

    // Method to highlight or unhighlight a dot
    highlightDot(month, highlight) {
        const highlightedRadius = this.width/60; 
        const normalRadius = this.width/90; 
        this.lineWrapper.selectAll('.dot')
            .filter(d => d && d.month) 
            .style('fill', d => d.month === month ? (highlight ? 'red' : 'orange') : 'orange')
            .attr('r', d => d.month === month ? (highlight ? highlightedRadius : normalRadius) : normalRadius);
        }

        // Method to add a line to the chart
    addLine(data, colour) {
        this.lineWrapper
            .append('path')
            .datum(data)
            .attr('class', 'line')
            .attr('d', this.line)
            .attr('fill', 'none')
            .attr('stroke', colour)
            .attr('stroke-width', 10);

        // Append circles (dots) to the line chart for each data point
        this.lineWrapper.selectAll('.dot')
            .data(data)
            .enter()
            .append('circle')
            .attr('class', 'dot')
            .attr('cx', d => this.xScale(d.month))
            .attr('cy', d => this.yScale(d.sun))
            .attr('r', this.width / 90)
            .attr('fill', 'orange')
            .on('mouseover', (event, d) => {
                if (d && d.month !== undefined) {
                    this.donutChart.highlightSegment(d.month, true);
                }
            })
            .on('mouseout', (event, d) => {
                this.donutChart.highlightSegment(d.month, false);
            });
}

    

    
}


//exports the LineChart class for use in other scripts
export default LineChart;

