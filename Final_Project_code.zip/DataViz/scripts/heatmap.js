class Heatmap {
    constructor(container, width, height, margin) {
        this.container = container;
        this.width = width;
        this.height = height;
        this.margin = margin;
    }

    InitialiseChart(data, chartTitle, xLabel, yLabel) {

        // Define an array of month names for labeling chart segments.
        const monthNames = [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];

        // Create an SVG element with specified dimensions and border
        this.svg = d3.select(this.container)
            .append('svg')
            .attr('width', this.width)
            .attr('height', this.height)
            .style('border', '2px solid #000');


        // Add chart title
        this.svg.append('text')
            .attr('class', 'chart-title')
            .attr('x', this.width / 2)
            .attr('y', this.margin.top / 2) // Adjust this to change the space above the title     
            .text(chartTitle);

        // Calculate inner dimensions of the chart
        const innerWidth = this.width - this.margin.left - this.margin.right;
        const innerHeight = this.height - this.margin.top - this.margin.bottom;

        // Create a group element for the chart
        const chartGroup = this.svg.append('g')
            .attr('transform', `translate(${this.margin.left}, ${this.margin.top})`);

        // Create scales for the x and y axes
        const xScale = d3.scaleBand()
            .domain(data.map(d => d.year))
            .range([0, innerWidth])
            .padding(0.05);

        const yScale = d3.scaleBand()
            .domain(monthNames) // Use month names for the domain
            .range([0, innerHeight])
            .padding(0.05)

        // Create a colour scale for sun levels
        const colourScale = d3.scaleSequential()
            .interpolator(d3.interpolateInferno)
            .domain([0, d3.max(data, d => d.sun)]);

        // Create the heatmap cells
        chartGroup.selectAll('rect')
            .data(data)
            .enter()
            .append('rect')
            .attr('x', d => xScale(d.year))
            .attr('y', d => yScale(monthNames[d.month - 1])) // Use month name for the y position
            .attr('width', xScale.bandwidth())
            .attr('height', yScale.bandwidth())
            .style('fill', d => colourScale(d.sun));


        // Create a tooltip div
        const tooltip = d3.select(this.container)
            .append("div")
            .attr("class", "tooltip")
            .style("opacity", 0);

        // Add hover events
        chartGroup.selectAll('rect')
            .on('mouseover', (event, d) => {
                tooltip.transition()
                    .duration(200)
                    .style('opacity', .9);

                tooltip.html(`Year: ${d.year}<br>Month: ${monthNames[d.month - 1]}<br>Sun: ${d.sun} hrs`)
                .style('left', (event.pageX + 10) + 'px') 
                .style('top', (event.pageY + 10) + 'px'); 

            })
            .on('mouseout', () => {
                tooltip.transition()
                    .duration(500)
                    .style('opacity', 0);
            });


        // Add x-axis to the chart
        this.svg.append('g')
            .attr('transform', `translate(${this.margin.left}, ${innerHeight + this.margin.top})`)
            .call(d3.axisBottom(xScale))       
            .selectAll('text')
            .attr("transform", "rotate(90)")
            .attr('class', 'x-axis')
            .attr('x', 20)
            .attr('y', -3)

        // Add y-axis to the chart
        this.svg.append('g')
            .attr('transform', `translate(${this.margin.left}, ${this.margin.top})`)
            .call(d3.axisLeft(yScale))
            .selectAll('text')
            .attr('class', 'y-axis')
            .attr('dx', -10)


        // Add x-axis label
        this.svg.append('text')
            .attr('class', 'x-label')
            .attr('x', this.width / 2 + 10)
            .attr('y', this.height-10)
            .attr('text-anchor', 'middle')
            .text(xLabel);

        // Add y-axis label
        this.svg.append('text')
            .attr('class', 'y-label')
            .attr('transform', `rotate(-90)`)
            .attr('x', -this.height / 2)
            .attr('y', this.margin.left / 4)
            .attr('text-anchor', 'middle')
            .text(yLabel);

            }
}

export default Heatmap;
