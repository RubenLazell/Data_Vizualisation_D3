
class DonutChart {
    // Constructor method for initialising the class with essential parameters.
    constructor(container, width, height, margin) {
        this.container = container;
        this.width = width;
        this.height = height;
        this.margin = margin;
    }

    // Method to initialise and render the donut chart.
    InitialiseChart(data, chartTitle, lineChartInstance) {
        // Create an SVG element within the specified dimensions and add a border.
        this.svg = d3.select(this.container)
            .append('svg')
            .attr('width', this.width)
            .attr('height', this.height)
            .style('border', '2px solid #000');

        // Add a title to the chart.
        this.svg.append('text')
            .attr('class', 'chart-title')
            .attr('x', this.width / 2)
            .attr('y', this.margin.top / 2) // Adjust this value to control title positioning.
            .text(chartTitle);

        // Calculate the radius for the donut chart.
        const radius = Math.min(this.width, this.height) / 2.6;

        // Create a group element for the chart and position it at the center.
        this.chartGroup = this.svg.append('g')
            .attr('transform', `translate(${this.width / 2},${this.height / 2}) rotate(-90)`)
            .attr('class', 'chart-border');

        //create custom colours for the chart
        const customcolours = [
            '#5B9BD5', // January: Cool blue
            '#4A7EBB', // February: Blue-green
            '#9BBB59', // March: Fresh green
            '#FFFF99', // April: Soft yellow
            '#FFD966', // May: Bright yellow
            '#FFD700', // June: Sunflower Yellow
            '#FF4500', // July: Deep orange
            '#C00000', // August: Red
            '#9E480E', // September: Earthy brown
            '#ED7D31', // October: Muted orange
            '#7F7F7F', // November: Gray
            '#ADD8E6'  // December: Pale blue
        ];

        // Create a colour scale based on the custom colours.
        const colour = d3.scaleOrdinal()
            .range(customcolours);

        // Define the pie layout for the data using the "averagesunlight" property.
        const pie = d3.pie()
            .value(d => d.averagesunlight);

        // Define the path generator for the chart arcs.
        const path = d3.arc()
            .outerRadius(radius - 10)
            .innerRadius(radius / 2);

        // Define an array of month names for labeling chart segments.
        const monthNames = [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];

        // Create groups for each arc in the chart.
        const arcs = this.chartGroup.selectAll('path')
            .data(pie(data))
            .enter()
            .append('g');

        // Append paths for each chart arc.
        arcs.append('path')
            .attr('d', path)
            .attr('fill', (d, i) => colour(d.data.month))

            // Event handling for mouseover: Enlarge the segment and highlight the corresponding dot in the LineChart.
            .on('mouseover', function(event, d) {
                d3.select(this)
                    .transition()
                    .duration(100)
                    .attr('d', d3.arc().outerRadius(radius + 10).innerRadius(radius / 2));
                lineChartInstance.highlightDot(d.data.month, true);
            })

            // Event handling for mouseout: Reset segment size and unhighlight the dot in the LineChart.
            .on('mouseout', function(event, d) {
                d3.select(this)
                    .transition()
                    .duration(200)
                    .attr('d', path);
                lineChartInstance.highlightDot(d.data.month, false);
            });

        // Add text labels to the chart segments.
        arcs.append('text')
            .attr('transform', function(d) {

                // Calculate the position for the text label using the centroid of the arc.
                const pos = path.centroid(d);
                const x = pos[0];
                const y = pos[1];

                // Apply translation and a 90-degree rotation for proper label placement.
                return `translate(${x},${y}) rotate(90)`;
            })
            .attr('dy', '.35em')
            .attr('text-anchor', 'middle')
            .attr('font-size', this.width / 60)
            .attr('font-weight', 'bold')

            // Append the appropriate text and rounded value to the arc.
            .text(d => `${monthNames[d.data.month - 1]}: ${Math.round(d.data.averagesunlight)}hrs`);

        // Create a legend for the chart.
        const legend = this.svg.append('g')
            .attr('class', 'legend')
            .attr('transform', `translate(${this.width - this.width / 6},${this.width / 20})`);

        // Add legend entries with coloured rectangles and month names.
        const legendEntries = legend.selectAll('.legend-entry')
            .data(data)
            .enter()
            .append('g')
            .attr('class', 'legend-entry')

            // Apply vertical translation for positioning.
            .attr('transform', (d, i) => `translate(0, ${i * this.width / 25})`);

        // Add coloured rectangles to the legend.
        legendEntries.append('rect')
            .attr('width', this.width / 30)
            .attr('height', this.width / 30)
            .attr('fill', (d, i) => colour(d.month));

        // Add text labels to the legend entries.
        legendEntries.append('text')
            .attr('x', 24)
            .attr('y', 9)
            .attr('dy', '.35em')
            .text((d) => ` ${monthNames[d.month - 1]}`);
    }

    // Method to highlight or unhighlight a specific chart segment.
    highlightSegment(month, highlight) {

        const radius = Math.min(this.width, this.height) / 2.6;
        const expandedRadius = radius + 20; 

        this.chartGroup.selectAll('path')

            .each(function(d) {
                if (d.data.month === month) {
                    d3.select(this)
                        .transition()
                        .duration(350)
                        .attr('d', d3.arc().outerRadius(highlight ? expandedRadius : radius - 10).innerRadius(radius / 2));
                }
            });
    }
}

// Export the DonutChart class for use in other parts of the code.
export default DonutChart;
