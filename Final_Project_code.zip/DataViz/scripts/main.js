// Imports chart classes from other scripts
import BarChartAnnual from './bar_chart_annual.js';
import LineChart from './line_chart.js';
import BubbleChart from './bubble_chart.js';
import DonutChart from './donut_chart.js';
import Heatmap from './heatmap.js';
import LineChart2 from './line_chart_2.js';



// Sets dimensions for the charts
const chartMargin = { top: window.innerWidth/40, right: window.innerWidth/53, bottom: window.innerWidth/20, left: window.innerWidth/20 };
let chartWidth = window.innerWidth/3.5;
let chartHeight = window.innerHeight/2.5; 

console.log(chartWidth)



// Reads data from CSV and processes it
d3.csv('WeatherDoc.csv').then(chartData => {
    chartData.forEach(d => {
        d.year = +d.year;
        d.max_temp = +d.max_temp;
        d.month = +d.month;
        d.rain = +d.rain;
        d.sun = +d.sun;
        d.lon = +d.lon; 
        d.lat = +d.lat;
    });

    // Define an array of month names for labeling chart segments.
    const monthNames = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];

    // Ensure data is properly formatted for the heatmap
    const heatmapData = chartData.map(d => ({
        year: d.year,
        month: d.month,
        sun: d.sun
    }));


    // Prepare data specifically for LineChart2
    const monthlyData = d3.rollups(
        chartData,
        group => ({
            sunlight: d3.mean(group, d => d.sun),
            rainfall: d3.mean(group, d => d.rain)
        }),
        d => d.month
    ).map(([month, values]) => ({
        month: monthNames[month - 1], 
        ...values
    }));

    // Groups data by month for average sun hours
    const monthlyAveragesunlight = d3.rollup(
        chartData,
        v => d3.mean(v, d => d.sun),
        d => d.month
    );

    

    // Additional data processing for other charts
    const averagesunlightData = d3.rollup(
        chartData,
        v => d3.mean(v, d => d.sun),
        d => d.name
    );

    const bubbleChartData = Array.from(averagesunlightData, ([name, averagesunlight]) => {
        const locationData = chartData.find(d => d.name === name);
        return {
            name,
            lon: locationData.lon,
            lat: locationData.lat,
            averagesunlight
        };
    });

    const donutChartData = Array.from(monthlyAveragesunlight, ([month, averagesunlight]) => ({
        month,
        averagesunlight
    }));

    const lineChartData = Array.from(monthlyAveragesunlight, ([month, sun]) => ({ month, sun }));



    // Declare the chart variables for the shared highlighting
    let lineChart;
    let donutChart;


    donutChart = new DonutChart('.donutchart', chartWidth, chartHeight, chartMargin);
    lineChart = new LineChart('.linechart', chartWidth, chartHeight, chartMargin, donutChart);

    //now for the non shared highlighting
    const barChart = new BarChartAnnual('.barchartannual', chartWidth, chartHeight, chartMargin);
    const heatmap = new Heatmap('.heatmap', chartWidth, chartHeight, chartMargin);
    const bubbleChart = new BubbleChart('.bubblechart', chartWidth, chartHeight, chartMargin);
    const lineChart2 = new LineChart2('.linechart2', chartWidth, chartHeight, chartMargin);


    // Now, initialise charts with data
    heatmap.InitialiseChart(heatmapData, 'Yearly Sun Exposure Trends by Month', 'Year', 'Month');
    donutChart.InitialiseChart(donutChartData, 'Average Sunlight by Month', lineChart);
    lineChart.InitialiseChart(lineChartData, 'Average Sunlight per Month', 'Month', 'Average Sun (hours)');
    barChart.InitialiseChart(chartData, 'Total Sun by Year (Per Location)', 'Year', 'Total Sun (hours)');
    bubbleChart.InitialiseChart(bubbleChartData, 'Average Sunlight by Proximity', 'Longitude', 'Latitude');
    lineChart2.initialiseChart('Monthly Sun and Rainfall', 'Months', 'Values');

    // Adds dropdown menu for bar chart and updates the chart
    barChart.addDropdown(chartData, barChart.updateChart.bind(barChart));
    // Adds the line to the line chart
    lineChart.addLine(lineChartData, 'orange');
    // Initialise LineChart2
    lineChart2.update(monthlyData);
});
