class LineChart2 {
    constructor(container, width, height, margin) {
        this.container = container;
        this.width = width;
        this.height = height;
        this.margin = margin;
        this.svg = null;
        this.xScale = null;
        this.yScale = null;
    }

    initialiseChart(chartTitle, xLabel, yLabel) {
 


        // Create an SVG element with specified dimensions and border
        this.svg = d3.select(this.container)
            .append('svg')
            .attr('width', this.width)
            .attr('height', this.height)
            .style('border', '2px solid #000');

        // Set up scales
        this.xScale = d3.scaleBand().range([0, this.width]);
        this.yScale = d3.scaleLinear().range([this.height, 0]);

        // Add chart title
        this.svg.append('text')
            .attr('class', 'chart-title')
            .attr('x', this.width / 2)
            .attr('y', this.margin.top / 2)   
            .text(chartTitle);

        // Add x-axis label
        this.svg.append('text')
            .attr('class', 'x-label')
            .attr('text-anchor', 'middle')
            .attr('x', this.width / 2)
            .attr('y', this.height-10)
            .text(xLabel);

        // Add y-axis label
        this.svg.append('text')
            .attr('class', 'y-label')
            .attr('transform', `rotate(-90)`)
            .attr('y', this.margin.left / 4)
            .attr('x', -this.height / 2)
            .attr('text-anchor', 'middle')
            .text(yLabel);

            
    
    }

    addLine(data, colour, key) {
        // Create line generator
        const line = d3.line()
            .x(d => this.xScale(d.month))
            .y(d => this.yScale(d[key]))
            .curve(d3.curveCardinal);

        // Append line to SVG
        this.svg.append("path")
            .datum(data)
            .attr("class", "line")
            .style("stroke", colour)
            .style("fill", "none") 
            .attr("d", line);
    }

    update(data) {
        // Use scalePoint for ordinal data like months
        this.xScale = d3.scalePoint()
            .domain(data.map(d => d.month))
            .range([this.margin.left, this.width - this.margin.right]);
        
        this.yScale.domain([0, d3.max(data, d => Math.max(d.sunlight, d.rainfall))])
            .range([this.height - this.margin.bottom, this.margin.top]);

        // Create x-axis
        // Use only the first 3 letters of the month name
        const xAxis = d3.axisBottom(this.xScale)
            .tickFormat(d => d.substring(0, 3)); 

        this.svg.append('g')
            .attr('class', 'x-axis')
            .attr('transform', `translate(0,${this.height - this.margin.bottom})`)
            .call(xAxis)
            .selectAll("text")
                .style("text-anchor", "end")
                .attr("dx", "-.8em")
                .attr("dy", ".15em")
                .attr("transform", "rotate(-65)"); 

        // Create y-axis
        const yAxis = d3.axisLeft(this.yScale)
            .tickPadding(10); 

        this.svg.append('g')
            .attr('class', 'y-axis')
            .attr('transform', `translate(${this.margin.left},0)`)
            .call(yAxis);

        // Add lines
        this.addLine(data, "orange", "sunlight");
        this.addLine(data, "blue", "rainfall");

        const legendData = [
            { name: "Sun (hrs)", colour: "orange" },
            { name: "Rainfall (mm)", colour: "blue" }
          ];
    
        this.addLegend(legendData);

    }

    addLegend(legendData) {
        // Create a legend group
        const legend = this.svg.append("g")
            .attr("class", "legend")
            .attr("transform", `translate(${this.width - this.margin.right - this.margin.left}, ${this.margin.top})`);
    
        // Add legend items
        legendData.forEach((legendItem, index) => {
            const legendGroup = legend.append("g")
                .attr("transform", `translate(0, ${index * 20})`); 
    
            // Append coloured rectangles
            legendGroup.append("rect")
                .attr("width", this.width/30)
                .attr("height", this.width/30)
                .style("fill", legendItem.colour);
    
            // Append text labels
            legendGroup.append("text")
                .attr("x", 24)
                .attr("y", 9)
                .style("text-anchor", "start")
                .style("font-family", "Arial")
                .text(legendItem.name);
        });
    }
    
}

export default LineChart2;
