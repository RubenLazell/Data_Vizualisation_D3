class BubbleChart {
    //constructor method for initialising the class
    constructor(container, width, height, margin) {
        //assigns provided parameters to class properties
        this.container = container;
        this.width = width;
        this.height = height;
        this.margin = margin;
    }

    //method to initialise the bubble chart
    InitialiseChart(data, chartTitle, xLabel, yLabel) {
        //create an SVG element with specified dimensions and border
        this.svg = d3.select(this.container)
            .append('svg')
            .attr('width', this.width)
            .attr('height', this.height)
            .style('border', '2px solid #000');

        // Add chart title
        this.svg.append('text')
            .attr('class', 'chart-title')
            .attr('x', this.width / 2)
            .attr('y', this.margin.top / 2) // Adjust this to change the space above the title     
            .text(chartTitle);

        //calculate inner dimensions of the chart
        const innerWidth = this.width - this.margin.left - this.margin.right;
        const innerHeight = this.height - this.margin.top - this.margin.bottom;

        //create a group element for the chart
        const chartGroup = this.svg.append('g')
            .attr('transform', `translate(${this.margin.left},${this.margin.top})`)
            .attr('class', 'chart-border'); 

        //create scales for longitude, latitude, and sunlight
        const lonScale = d3.scaleLinear()
            .domain([
                d3.min(data, d => +d.lon) - 1,
                d3.max(data, d => +d.lon) + 1
            ])
            .range([0, innerWidth]);

        //define a linear scale for latitude
        const latScale = d3.scaleLinear()
            .domain([
                d3.min(data, d => +d.lat) - 1,
                d3.max(data, d => +d.lat) + 1
            ])
            .range([innerHeight, 0]);

        


        //define a linear scale for sunlight values
        const sunScale = d3.scaleLinear()

        //set the domain to the extent of sunlight values in the data
        .domain(d3.extent(data, d => +d.averagesunlight))

        //map the range to circle radius between 5 and 50
        .range([this.width/120, this.width/20]);

        // Define a custom colour scale interpolator
        const colourInterpolator = t => {
            // Transition from green (0) through orange (0.5) to red (1)
            return t < 0.5 ? d3.interpolateRgb('red', 'orange')(t * 2) : d3.interpolateRgb('orange', 'green')((t - 0.5) * 2);
        };

        // Create the colour scale using the custom interpolator
        const colourScale = d3.scaleSequential(colourInterpolator)
            .domain(d3.extent(data, d => +d.averagesunlight));


        const pinnedLabels = new Set();


        //create circles for each data point with x and y position as the scaled lon and lat respectively, and radius as scaled sunlight
        //Update circle creation to use colour scale
        const circles = chartGroup.selectAll('circle')
            .data(data)
            .enter()
            .append('circle')
            .attr('cx', d => lonScale(+d.lon))
            .attr('cy', d => latScale(+d.lat))
            .attr('r', d => sunScale(+d.averagesunlight))
            .attr('fill', d => colourScale(+d.averagesunlight)) // Apply colour scale here
            .attr('stroke', 'black')
            .attr('stroke-width', this.width/350)

            // Toggle label pinning
            .on('click', function(event, d) {
                const label = labels.nodes()[data.indexOf(d)];
        
                if (pinnedLabels.has(label)) {
                    pinnedLabels.delete(label);
                    d3.select(label).style('visibility', 'hidden');
                } else {
                    pinnedLabels.add(label);
                    d3.select(label).style('visibility', 'visible');
                }
            })

            // Show label on mouseover if not pinned
            .on('mouseover', (event, d) => {
                const label = labels.nodes()[data.indexOf(d)];
                if (!pinnedLabels.has(label)) {
                    d3.select(label).style('visibility', 'visible');
                }
                d3.select(event.currentTarget).attr('fill', 'aqua');
            })

            // Hide label on mouseout if not pinned
            .on('mouseout', (event, d) => {
                const label = labels.nodes()[data.indexOf(d)];
                if (!pinnedLabels.has(label)) {
                    d3.select(label).style('visibility', 'hidden');
                }
                d3.select(event.currentTarget).attr('fill', d => colourScale(+d.averagesunlight));
            });

            
        
        //create labels for each data point
        const labels = chartGroup.selectAll('.label')
            .data(data)
            .enter()
            .append('text')
            .attr('class', 'label')

            //sets the x and y position of the label using the scaled lon and lat
            .attr('x', d => lonScale(+d.lon))
            .attr('y', d => latScale(+d.lat))

            .attr('text-anchor', 'middle')
            .attr('dy', -15)
            
            .text(d => d.name)
            .attr('font-family', 'Calibri')
            .attr('font-size', this.width/25)
            .attr('font-weight', 'bold')
            .attr('fill', 'black')
            .style('visibility', 'hidden')
            .style('pointer-events', 'none');

        
        
            
        //adjust label position based on proximity to circles
        labels.each(function(d) {
            //select the current label and associated circle
            const label = d3.select(this);
            const circle = circles.nodes()[data.indexOf(d)];
            
            //get the radius of the circle
            const circleRadius = sunScale(+d.averagesunlight);

            //get the x and y coordinates of the label
            const labelX = +label.attr('x');
            const labelY = +label.attr('y');

            //get the centre coordinates of the circle
            const circlecentreX = +circle.getAttribute('cx');
            const circlecentreY = +circle.getAttribute('cy');

            //calculate the distance between the label and circle centres
            const distance = Math.sqrt((circlecentreX - labelX)**2 + (circlecentreY - labelY)**2);

            //if the distance is less than the sum of the circle radius and a small buffer (5),
            //adjust the label's vertical position (dy)
            if (distance < circleRadius + 5) { 
                label.attr('dy', circleRadius + 15); 
            }
});

            //add x-axis and y-axis labels if not already present
            if (this.svg.selectAll('.x-label').empty()) {
                //append x-axis label
                this.svg.append('text')
                    .attr('class', 'x-label')
                    .attr('text-anchor', 'middle')
                    .attr('x', this.width / 2)
                    .attr('y', this.height - this.height/12)
                    .text(xLabel);

                //append y-axis label
                this.svg.append('text')
                    .attr('class', 'y-label')
                    .attr('text-anchor', 'middle')
                    .attr('transform', 'rotate(-90)')
                    .attr('x', -this.height/2)
                    .attr('y', this.margin.left-50)
                    .text(yLabel);
            }

            //add x-axis and y-axis elements
            const xAxis = d3.axisBottom(lonScale);
            chartGroup.append('g')
                .attr('class', 'x-axis')
                .attr('transform', `translate(0, ${innerHeight })`)
                .call(xAxis)


            const yAxis = d3.axisLeft(latScale)
                .tickPadding(10); 

            chartGroup.append('g')
                .attr('class', 'y-axis')
                .call(yAxis);
            }
        }
//export the BubbleChart class
export default BubbleChart;
