//imports all of the chart classes from the other scripts
import BarChartAnnual from './bar_chart_annual.js';
import LineChart from './line_chart.js';
import BubbleChart from './bubble_chart.js';
import DonutChart from './donut_chart.js';

//sets the dimensions of the margins and the  width and height that will be used to create the svgs
const chartMargin = { top: 80, right: 60, bottom: 60, left: 70 };
const chartWidth = 900;
const chartHeight = 600;

//reads the data from the csv, and then processes it using a callback function and ten iterates through each row
//makes sure that all of the paramaters are parsed as numbers using +
d3.csv('WeatherDoc.csv').then(chartData => {
    chartData.forEach(d => {
        d.year = +d.year;
        d.max_temp = +d.max_temp;
        d.month = +d.month;
        d.rain = +d.rain;
        d.sun = +d.sun;
        d.lon = +d.lon; 
        d.lat = +d.lat;
    });

//group our data from the csv by month and the average monthly sun hours over all locations using d3.rollup
    const monthlyAverageSunfall = d3.rollup(
        chartData,
        v => d3.mean(v, d => d.sun),
        d => d.month
    );

//same as above but it calculates average sunfall for each location instead of for each month
    const averageSunfallData = d3.rollup(
        chartData,
        v => d3.mean(v, d => d.sun),
        d => d.name
);

//exact same as monthlyAverageSunfall but for rain instead of sun
    const monthlyRainfall = d3.rollup(
        chartData,
        v => d3.mean(v, d => d.rain),
        d => d.month
    );

//converts monthlyAverageSunfall into an array of objects with properties 'month' and 'averageSunfall'
    const donutChartData = Array.from(monthlyAverageSunfall, ([month, averageSunfall]) => ({
        month,
        averageSunfall
    }));

//converts monthly rainfall into an array of objects with properties 'month' and 'rain'
    const lineChartData = Array.from(monthlyRainfall, ([month, rain]) => ({ 
        month, 
        rain }));

////converts averageSunfallData into an array of objects with properties 'name', 'lon', 'lat', and 'averageSunfall'

    const bubbleChartData = Array.from(averageSunfallData, ([name, averageSunfall]) => {
        const locationData = chartData.find(d => d.name === name);
        return {
            name,
            lon: locationData.lon,
            lat: locationData.lat,
            averageSunfall
        };
    });

//creates and initialises the donut chart
    const donutChart = new DonutChart('.donutchart', chartWidth, chartHeight, chartMargin);
    donutChart.InitialiseChart(donutChartData, 'Average Sunfall by Month');
    
//creates and initialises bar chart with the data straigth from the csv, it will be aggregated in the bar chart javascript file
    const barChart = new BarChartAnnual('.barchartannual', chartWidth, chartHeight, chartMargin);
    barChart.InitialiseChart(chartData, 'Annual Maximum Temperature by Year (Per Location)', 'Year', 'Max Temperature (°C)');

//creates and initialises line chart
    const lineChart = new LineChart('.linechart', chartWidth, chartHeight, chartMargin);
    lineChart.InitialiseChart(lineChartData, 'Average Rainfall per Month', 'Month', 'Average Rain (mm)');

// creates and initialises bubble chart
    const bubbleChart = new BubbleChart('.bubblechart', chartWidth, chartHeight, chartMargin);
    bubbleChart.InitialiseChart(bubbleChartData, 'Average Sunfall by Proximity', 'Longitude', 'Latitude');

// creates a dropdown menu for the bar chart and updates the chart with it, these are both using functions in the class
    barChart.addDropdown(chartData, barChart.updateChart.bind(barChart));
// adds the the line to the line chart
    lineChart.addLine(lineChartData, 'blue');

});
