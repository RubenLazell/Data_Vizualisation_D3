//defines a class named BarChartAnnual
class BarChartAnnual {

//constructor method used initialising the class
    constructor(container, width, height, margin) {
        
        //assigns the values to class properties to be used in this file
        this.container = container;
        this.width = width;
        this.height = height;
        this.margin = margin;

        //calculates the inner dimensions of the chart
        this.innerHeight = this.height - margin.top - margin.bottom;
        this.innerWidth = this.width - margin.left - margin.right;
    }

//renders the elements in the InitialiseChart method from main.js
    InitialiseChart(data, chartTitle, xLabel, yLabel) {

//select the container element specified when the class was instantiated
//creates an svg with width and height set up in main.js and makes a border around it
        this.svg = d3.select(this.container)
            .append('svg')
            .attr('width', this.width)
            .attr('height', this.height)
            .style('border', '2px solid #000'); 

//creates chart title, places it centrally and takes the text from main.js
        this.svg
            .append('text')
            .attr('class', 'chart-title')
            .attr('x', this.width / 4.5)
            .attr('y', this.margin.top - 30)
            .text(chartTitle);

//appends a new group element as a child of the SVG and sets the transformsation of the group
        this.chartGroup = this.svg.append('g')
            .attr('transform', `translate(${this.margin.left},${this.margin.top})`)
            .attr('class', 'chart-border'); 

//finds the maximum max_temp and uses it to set the y domain ensuring all data lies within the y range (0 and maxMaxTemp)
        const maxMaxTemp = d3.max(data, d => d.max_temp);
        this.yScale = d3.scaleLinear()
            .domain([0, maxMaxTemp])
            .range([this.innerHeight, 0]);

//creates a new instance of a band scale since the data is discrete
//sets the input domain of the scale by using the map function to extract the year from each element in data
//sets the range by selecting the minimum and maximum output values
//adds padding between the bands in the scale
        this.xScale = d3.scaleBand()
            .domain(data.map(d => d.year))
            .range([0, this.innerWidth])
            .padding(0.5);

//selects all exisiting rect elements in the chartgroup
//binds the provided data to the selected rects
//creates a selection of data points that haven't been associated with DOM elements and then creates new rects for these

        this.chartGroup.selectAll('rect')
            .data(data)
            .enter()
            .append('rect');

//appends a new group element to the this.chartGroup that will be used to contain the x-axis
//uses D3s axisBottom function to create the x-axis using the x scale
//translates the group element downwards by a distance equal to this.innerHeight to position the x axis at the bottom of the chart`
//selects all text elements associated with the x-axis ticks
//makes sure it is centred
        this.chartGroup.append('g')
            .call(d3.axisBottom(this.xScale))
            .attr('transform', `translate(0, ${this.innerHeight})`)
            .selectAll('text')
            .style('text-anchor', 'middle');


//creates the x axis label svg
//centres the label and postions it to be correct in the y direction
//gets the text to be used for the axis
        this.svg.append('text')
            .attr('class', 'x-label')
            .attr('text-anchor', 'middle')
            .attr('x', this.width / 2)
            .attr('y', this.height - this.margin.bottom + 40)
            .text(xLabel);

//places the y-axis elements inside a group element
        this.chartGroup.append('g')
        .attr('class', 'y-axis');

//creates the y axis label svg
//rotates it 90 degrees clockwise so it is parallel to the y axis
//centres the label and postions it to be correct in the x direction
//gets the text to be used for the axis
        this.svg.append('text')
            .attr('class', 'y-label')
            .attr('text-anchor', 'middle')
            .attr('transform', 'rotate(-90)')
            .attr('x', -this.height / 2)
            .attr('y', this.margin.left - 30)
            .text(yLabel);
    }


    //begins the updateChart method that takes two parameters: name and data and declares a variable named filteredData
    updateChart(name, data) {
        let filteredData;

        //checks if the variable name has been assigned a value 
        if (name === null) {
            //if it hasn't yet, aggregate data for all names, this is when the user selects all locations which is mentioned later
            const yearMaxTempMap = new Map();    
            data.forEach(d => {
                //checks if the yearMaxTempMap does not have an entry for the current year or 
                //if the maximum temperature d.max_temp for the current entry is greater than 
                //the existing entry for the same year in yearMaxTempMap

                //if either answer is yes it updates the entry in the map with the current year and maximum temperature
                if (!yearMaxTempMap.has(d.year) || d.max_temp > yearMaxTempMap.get(d.year)) {
                    yearMaxTempMap.set(d.year, d.max_temp);
                }
            });
            //creates a new array called filteredData where each object has properties year and max_temp.
            filteredData = Array.from(yearMaxTempMap, ([year, max_temp]) => ({ year, max_temp }));
        //if name is not null
        } else {
            //filters the data array to only include entries with a matching name
            filteredData = data.filter(d => d.name === name);
            const yearMaxTempMap = new Map();
            
            //aggregates maximum temperatures by year
            filteredData.forEach(d => {
                if (!yearMaxTempMap.has(d.year) || d.max_temp > yearMaxTempMap.get(d.year)) {
                    yearMaxTempMap.set(d.year, d.max_temp);
                }
            });
            //converts the aggregated data to the filteredData array
            filteredData = Array.from(yearMaxTempMap, ([year, max_temp]) => ({ year, max_temp }));
        }


        //calculates the maximum value of max_temp within filteredData
        const maxMaxTemp = d3.max(filteredData, d => d.max_temp);

        //sets up the x and y scale for the chart by mapping the year to x and y position of inner width and height
        //the +3 is to ensure there is extra space at the top for context
        this.xScale.domain(filteredData.map(d => d.year)).range([0, this.innerWidth]);
        this.yScale.domain([0, maxMaxTemp + 3]).range([this.innerHeight, 0]);
    
        // elects the y-axis group and applies the left oriented axis
        this.chartGroup.select('.y-axis').call(d3.axisLeft(this.yScale));
    
        //selects all existing rect eles within the chart group and binds the aggregated data to them
        const bars = this.chartGroup.selectAll('rect').data(filteredData);
    
        //selects all data points without DOM elements and appends new rect elements
        bars.enter().append('rect')
            //combines the new and existing elements
            .merge(bars)
            //sets the starting x and y positions of the bars with scaling
            .attr('x', d => this.xScale(d.year))
            .attr('y', d => this.yScale(d.max_temp))

            //ensures that the bars are evenly spaced
            .attr('width', this.xScale.bandwidth())

            //sets the height of the bars based on the difference between
            //the height of the chart and the y-position of the bar
            //this is because of the origin of svgs starting at the top left of the svg
            .attr('height', d => this.innerHeight - this.yScale(d.max_temp))

            //sets the fill colour of the bars based on the max_temp value
            //gives the bars a black outline
            .attr('fill', d => (d.max_temp >= 22) ? 'green' : (d.max_temp >= 18) ? 'orange' : 'red')
            .attr('stroke', 'black') // Outline colour
            .attr('stroke-width', 2); // Outline width
        //removes redundant bars
        bars.exit().remove();
    }
    

    
    
    //creates a function to add a dropdown 
    addDropdown(data, updateFunction) {

        //creates a container element for the dropdown
        const dropdownContainer = d3.select(this.container)

            //appends a div element to the container and sets some styles to do with correct positioning
            .append('div')
            .attr('class', 'dropdown-container')
            .style('position', 'static')
            .style('top', '10px')
            .style('right', '10px');
    
        //creates an array of unique names of locations and appends them to the dropdown menu
        //also adds an option for all names
        const names = Array.from(new Set(data.map(d => d.name)));
        names.push('All Locations');
    

        const nameDropdown = dropdownContainer
            //appends the drop down to the container
            .append('select')
            .attr('class', 'name-dropdown')
            .style('position', 'absolute')

            //sets up an event listener for when the value of the dropdown changes
            .on('change', function() {

                //extracts the selected name when the user selects it
                const selectedName = d3.select(this).property('value');

                //checks if the user selected 'all locations'
                //if so it calls the updateFunction from earlier and passes null
                //if not, it will pass the selected name to update function
                if (selectedName === 'All Locations') {
                    updateFunction(null, data);
                } else {
                    updateFunction(selectedName, data);
                }
            });
    

        //selects all of the options in the dropdown and binds the relevant data to them
        nameDropdown.selectAll('option')
            .data(names)
            .enter()
            .append('option')
            .attr('value', d => d)
            .text(d => d);
    
        //sets the default name to the first name in the list
        const defaultName = names[0];
        //makes sure the dropdown is 
        nameDropdown.property('value', defaultName);
        
        //sets the chart to render the first name in the dropdown before the user has selected anything
        updateFunction(defaultName, data);
    }
    
}
//exports the class to be used in main.js
export default BarChartAnnual;
