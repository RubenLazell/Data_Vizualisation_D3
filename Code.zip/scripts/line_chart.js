// Defines a class named LineChart
class LineChart {

    //constructor method for initialising the class
    constructor(container, width, height, margin) {
        //assigns the provided values to class properties
        this.container = container;
        this.width = width;
        this.height = height;
        this.margin = margin;
    }

    //method to initialise the line chart with provided data, title, x-axis label, and y-axis label
    InitialiseChart(data, chartTitle, xLabel, yLabel) {
        //determines the domain for x-axis and y-axis
        const xDomain = d3.extent(data, d => d.month);
        const yDomain = [0, d3.max(data, d => d.rain)];

        //array of month names for labeling the x-axis
        const monthNames = [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];

        //creates an SVG element with specified dimensions and a border
        this.svg = d3
            .select(this.container)
            .append('svg')
            .attr('width', this.width + this.margin.left + this.margin.right)
            .attr('height', this.height + this.margin.top + this.margin.bottom)
            .style('border', '2px solid #000');

        //appends the chart title to the SVG element
        this.svg
            .append('text')
            .attr('class', 'chart-title')
            .attr('x', this.width / 2.35)
            .attr('y', this.margin.top)
            .text(chartTitle);

        //sets up x and y scales for the chart
        this.xScale = d3.scaleLinear().domain(xDomain).range([0, this.width]);
        this.yScale = d3.scaleLinear().domain(yDomain).range([this.height, 0]);

        //defines the line function for the chart
        this.line = d3
            .line()
            .x(d => this.xScale(d.month))
            .y(d => this.yScale(d.rain))
            .curve(d3.curveLinear);

        //appends a group element to contain the chart elements
        this.lineWrapper = this.svg
            .append('g')
            .attr('transform', `translate(${this.margin.left}, ${this.margin.top})`)
            .attr('class', 'chart-border'); 

        //adds x-axis and labels
        this.lineWrapper
            .append('g')
            .attr('class', 'x axis')
            .attr('transform', `translate(0, ${this.height})`)
            .call(d3.axisBottom(this.xScale)
                .tickFormat((d) => monthNames[d - 1])
            );

        //adds y-axis and labels
        this.lineWrapper
            .append('g')
            .attr('class', 'y axis')
            .call(d3.axisLeft(this.yScale));

        //appends x-axis label
        this.svg
            .append('text')
            .attr('class', 'x-label')
            .attr('text-anchor', 'middle')
            .attr('x', this.margin.left + this.width / 2)
            .attr('y', this.height + this.margin.top + this.margin.bottom - 20)
            .text(xLabel);

        //appends y-axis label
        this.svg
            .append('text')
            .attr('class', 'y-label')
            .attr('text-anchor', 'middle')
            .attr('transform', 'rotate(-90)')
            .attr('x', -this.margin.top - this.height / 2)
            .attr('y', 30 + this.margin.left - this.margin.right)
            .text(yLabel);

        //sets up a tooltip for data points
        this.tooltip = d3
            .select(this.container)
            .append('div')
            .attr('class', 'tooltip')
            .style('opacity', 0);

        //adds a cursor line for highlighting data points
        this.cursorLine = this.lineWrapper.append('line')
            .attr('class', 'cursor-line')
            .attr('x1', 0)
            .attr('x2', 0)
            .attr('y1', 0)
            .attr('y2', this.height)
            .style('stroke', '#ccc')
            .style('stroke-dasharray', '4');

        //adds a label for cursor tooltip
        this.cursorLabel = this.svg.append('text')
            .attr('class', 'cursor-label')
            .attr('text-anchor', 'middle')
            .attr('x', 0)
            .attr('y', 0)
            .style('font-size', '12px');

        //listens for mouse movement on the SVG element
        this.svg.on('mousemove', event => {

            //extracts the x-coordinate of the mouse pointer
            const [x] = d3.pointer(event);

            //converts the x-coordinate to the corresponding x-value in the data using the xScale
            const xValue = this.xScale.invert(x - this.margin.left);

            //function to find the insertion point for xValue in the sorted data array
            const bisect = d3.bisector(d => d.month).left;

            //finds the index of the data point to the left of xValue
            const index = bisect(data, xValue, 1);

            //gets the data points on either side of xValue for interpolation
            const d0 = data[index - 1];
            const d1 = data[index];

            //determines which data point to use for interpolation based on proximity to xValue
            const interpolatedValue = xValue - d0.month > d1.month - xValue ? d1 : d0;

            //extracts the y-value of the interpolated data point
            const yValue = interpolatedValue.rain;

            //finds the corresponding month name for the interpolated data point
            const monthName = monthNames[Math.round(interpolatedValue.month) - 1];

            //updates the position and dimensions of the cursor line
            this.cursorLine
                .attr('x1', this.xScale(interpolatedValue.month))
                .attr('x2', this.xScale(interpolatedValue.month))
                .attr('y1', 0)
                .attr('y2', this.height);

            //updates the position and text content of the cursor label
            this.cursorLabel
                .attr('x', this.xScale(interpolatedValue.month))
                .attr('y', this.height + this.margin.top + this.margin.bottom - 5)
                .text(`Month: ${monthName}, Rain: ${yValue.toFixed(2)} mm`);

            //updates the content and position of the tooltip
            this.tooltip
                .html(`Month: ${monthName}, Rain: ${yValue.toFixed(2)} mm`)
                .style('left', event.pageX + 10 + 'px')
                .style('top', event.pageY - 50 + 'px')
                .style('opacity', 0.9);
        });

        //listens for mouse leaving the chart area
        this.svg.on('mouseout', () => {

            //hides the tooltip by setting its opacity to 0
            this.tooltip.style('opacity', 0);

            //resets the cursor line to its initial position (hidden)
            this.cursorLine.attr('x1', 0).attr('x2', 0);

            //resets the cursor label position to its initial position (hidden)
            this.cursorLabel.attr('x', 0).attr('y', 0);
        });
    }

    //method to add a line to the chart
    addLine(data, colour) {
        //appends a path element to the lineWrapper group to represent the line
        //associates the provided data with the path element
        //assigns a class 'line' for styling purposes
        //defines the path of the line using the line function
        //specifies that the path should have no fill
        //sets the stroke (line) colour to the specified colour
        //sets the stroke width to 2
        this.lineWrapper
            .append('path')
            .datum(data)
            .attr('class', 'line')
            .attr('d', this.line)
            .attr('fill', 'none')
            .attr('stroke', colour)
            .attr('stroke-width', 2.5);

    
    
    
    
        //selects all existing dots with the specified colour class and binds data to them
        //enters a selection of data points that are not yet associated with DOM elements
        //appends a circle element for each data point
        //assigns classes 'dot' and 'dot-' followed by the specified colour for styling and identification
        //sets the x-coordinate based on the month value using the xScale
        //sets the y-coordinate based on the rain value using the yScale
        //sets the radius of the circle to 3
        //sets the fill colour of the circle to the specified colour
        this.lineWrapper
            .selectAll('.dot-' + colour)
            .data(data)
            .enter()
            .append('circle')
            .attr('class', 'dot dot-' + colour)
            .attr('cx', d => this.xScale(d.month))
            .attr('cy', d => this.yScale(d.rain))
            .attr('r', 3)
            .attr('fill', colour);
}

    }


//exports the LineChart class for use in other scripts
export default LineChart;
