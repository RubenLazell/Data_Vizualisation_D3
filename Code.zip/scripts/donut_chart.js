//defines DonutChart class
class DonutChart {
    //constructor method for initialising the class
    constructor(container, width, height, margin) {
        this.container = container;
        this.width = width;
        this.height = height;
        this.margin = margin;
    }

    //method to initialise the donut chart
    InitialiseChart(data, chartTitle) {
        //create an SVG element with specified dimensions and border
        this.svg = d3.select(this.container)
            .append('svg')
            .attr('width', this.width)
            .attr('height', this.height)
            .style('border', '2px solid #000');

        //append chart title to the SVG
        this.svg
            .append('text')
            .attr('class', 'chart-title')
            .attr('x', (this.width - this.margin.left - this.margin.right) / 2.35)
            .attr('y', 40)
            .text(chartTitle);

        //calculate radius for the donut chart
        const radius = Math.min(this.width, this.height) / 2.6;

        //create a group element for the chart
        this.chartGroup = this.svg.append('g')
            .attr('transform', `translate(${this.width / 2},${this.height / 2}) rotate(-90)`)
            .attr('class', 'chart-border'); 

        //create custom colours for the chart
        const customcolours = [
            '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
            '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf',
            '#aec7e8', '#ffbb78',
        ];

        //create a colour scale for the chart
        const colour = d3.scaleOrdinal()
            .range(customcolours);

        //define pie layout for the data
        const pie = d3.pie()
            .value(d => d.averageSunfall);

        //define the path for the arcs in the donut chart
        const path = d3.arc()
            .outerRadius(radius - 10)
            .innerRadius(radius / 2);

        //define an array of month names
        const monthNames = [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];

        //create groups for each arc in the chart
        const arcs = this.chartGroup.selectAll('path')
            .data(pie(data))
            .enter()
            .append('g');

        //append paths for each arc
        arcs.append('path')
            //define the path using the 'path' function
            .attr('d', path)
            //fill colour based on month data
            .attr('fill', (d, i) => colour(d.data.month))
            .on('mouseover', function() {
                d3.select(this)
                    .transition()
                    .duration(350)
                    //creates larger segment effect
                    .attr('d', d3.arc().outerRadius(radius + 10).innerRadius(radius / 2));
            })
            .on('mouseout', function() {
                d3.select(this)
                    .transition()
                    .duration(200)
                    //resets the larger segment effect
                    .attr('d', path);
            });

        //add text labels to the arcs
        arcs.append('text')
            .attr('transform', function(d) {

                //calculate the position for the text label using centroid of the arc, ie: the point at which the arc's centre is
                const pos = path.centroid(d);

                //extract the x and y coordinates from the centroid
                const x = pos[0];
                const y = pos[1];

                //apply a translation and a 90-degree rotation for proper label placement
                return `translate(${x},${y}) rotate(90)`; 
            })
            .attr('dy', '.35em')
            .attr('text-anchor', 'middle')

            //append the correct text and rounded value to the arc, 
            .text(d => `${monthNames[d.data.month - 1]}: ${Math.round(d.data.averageSunfall)}hrs`);

        //create a legend for the chart
        const legend = this.svg.append('g')
            .attr('class', 'legend')
            .attr('transform', `translate(${this.width - 100},${20})`);

        //add legend entries with colours
        const legendEntries = legend.selectAll('.legend-entry')
            .data(data)
            .enter()
            .append('g')
            .attr('class', 'legend-entry')

            //Apply translation for vertical positioning
            .attr('transform', (d, i) => `translate(0, ${i * 20})`);

        //add coloured rectangles to the legend with the names of the months
        legendEntries.append('rect')
            .attr('width', 18)
            .attr('height', 18)
            .attr('fill', (d, i) => colour(d.month));

        //add text labels to the legend entries
        legendEntries.append('text')
            .attr('x', 24)
            .attr('y', 9)
            .attr('dy', '.35em')
            .text((d) => ` ${monthNames[d.month - 1]}`);
    }
}

//export the DonutChart class
export default DonutChart;
