//defines a class named BubbleChart
class BubbleChart {
    //constructor method for initialising the class
    constructor(container, width, height, margin) {
        //assigns provided parameters to class properties
        this.container = container;
        this.width = width;
        this.height = height;
        this.margin = margin;
    }

    //method to initialise the bubble chart
    InitialiseChart(data, chartTitle, xLabel, yLabel) {
        //create an SVG element with specified dimensions and border
        this.svg = d3.select(this.container)
            .append('svg')
            .attr('width', this.width)
            .attr('height', this.height)
            .style('border', '2px solid #000');

        //append chart title to the SVG
        this.svg
            .append('text')
            .attr('class', 'chart-title')
            .attr('x', (this.width - this.margin.left - this.margin.right) / 2.35)
            .attr('y', 40)
            .text(chartTitle);

        //calculate inner dimensions of the chart
        const innerWidth = this.width - this.margin.left - this.margin.right;
        const innerHeight = this.height - this.margin.top - this.margin.bottom;

        //create a group element for the chart
        const chartGroup = this.svg.append('g')
            .attr('transform', `translate(${this.margin.left},${this.margin.top})`)
            .attr('class', 'chart-border'); 

        //create scales for longitude, latitude, and sunfall
        const lonScale = d3.scaleLinear()
            .domain([
                d3.min(data, d => +d.lon) - 1,
                d3.max(data, d => +d.lon) + 1
            ])
            .range([0, innerWidth]);

        //define a linear scale for latitude
        const latScale = d3.scaleLinear()

        //set the domain to the extent of latitude values in the data
        .domain(d3.extent(data, d => +d.lat))

        //map the range to fit within the inner height of the chart
        .range([innerHeight, 0]);

        //define a linear scale for sunfall values
        const sunScale = d3.scaleLinear()

        //set the domain to the extent of sunfall values in the data
        .domain(d3.extent(data, d => +d.averageSunfall))

        //map the range to circle radius between 5 and 50
        .range([5, 50]);


        //create circles for each data point sith x and y position as the scaled lon and lat respectively, and radius as scaled sunfall
        const circles = chartGroup.selectAll('circle')
            .data(data)
            .enter()
            .append('circle')
            .attr('cx', d => lonScale(+d.lon))
            .attr('cy', d => latScale(+d.lat))
            .attr('r', d => sunScale(+d.averageSunfall))
            .attr('fill', 'aqua')
            .attr('stroke', 'black')
            .attr('stroke-width', 2)
            .on('click', function() {

                //toggle label visibility on click

                //retrieves the label element associated with the clicked circle in the Bubble Chart
                const label = labels.nodes()[data.indexOf(d3.select(this).datum())];

                //checks whether the label is currently set to 'visible' or 'hidden'
                const currentVisibility = d3.select(label).style('visibility');

                //if 'hidden', then newVisibility will be set to 'visible', otherwise, it will be set to 'hidden'
                const newVisibility = currentVisibility === 'hidden' ? 'visible' : 'hidden';

                //toggles the visibility of the label element based on the calculated condition
                d3.select(label).style('visibility', newVisibility);

                //stores the value of newVisibility in the local storage under the key 'labelVisibility'
                localStorage.setItem('labelVisibility', JSON.stringify(newVisibility));
            })
            .on('mouseover', function() {
                //change circle colour on mouseover
                d3.select(this).attr('fill', 'blue');
            })
            .on('mouseout', function() {
                //restore circle colour on mouseout
                d3.select(this).attr('fill', 'aqua');
            });
        
        //create labels for each data point
        const labels = chartGroup.selectAll('.label')
            .data(data)
            .enter()
            .append('text')
            .attr('class', 'label')

            //sets the x and y position of the label using the scaled lon and lat
            .attr('x', d => lonScale(+d.lon))
            .attr('y', d => latScale(+d.lat))

            .attr('text-anchor', 'middle')

            //move the label up by 15
            .attr('dy', -15)
            
            .text(d => d.name)
            .attr('font-family', 'Calibri')
            .attr('font-size', 23)
            .attr('font-weight', 'bold')
            .attr('fill', 'black')
            .style('visibility', 'hidden')
            .style('pointer-events', 'none');
        
            
        //adjust label position based on proximity to circles
        labels.each(function(d) {
            //select the current label and associated circle
            const label = d3.select(this);
            const circle = circles.nodes()[data.indexOf(d)];
            
            //get the radius of the circle
            const circleRadius = sunScale(+d.averageSunfall);

            //get the x and y coordinates of the label
            const labelX = +label.attr('x');
            const labelY = +label.attr('y');

            //get the centre coordinates of the circle
            const circlecentreX = +circle.getAttribute('cx');
            const circlecentreY = +circle.getAttribute('cy');

            //calculate the distance between the label and circle centres
            const distance = Math.sqrt((circlecentreX - labelX)**2 + (circlecentreY - labelY)**2);

            //if the distance is less than the sum of the circle radius and a small buffer (5),
            //adjust the label's vertical position (dy)
            if (distance < circleRadius + 5) { 
                label.attr('dy', circleRadius + 15); 
            }
});

            //add x-axis and y-axis labels if not already present
            if (this.svg.selectAll('.x-label').empty()) {
                //append x-axis label
                this.svg.append('text')
                    .attr('class', 'x-label')
                    .attr('text-anchor', 'middle')
                    .attr('x', this.width / 2)
                    .attr('y', this.height - this.margin.bottom + 40)
                    .text(xLabel);

                //append y-axis label
                this.svg.append('text')
                    .attr('class', 'y-label')
                    .attr('text-anchor', 'middle')
                    .attr('transform', 'rotate(-90)')
                    .attr('x', -this.height / 2)
                    .attr('y', this.margin.left - 30)
                    .text(yLabel);
            }

            //add x-axis and y-axis elements
            const xAxis = d3.axisBottom(lonScale);
            const xAxisElement = chartGroup.append('g')
                .attr('class', 'x-axis')
                .attr('transform', `translate(0, ${innerHeight})`)
                .call(xAxis);

            //style x-axis text
            xAxisElement.selectAll('text')
                .attr('font-size', 14);

            const yAxis = d3.axisLeft(latScale);
            const yAxisElement = chartGroup.append('g')
                .attr('class', 'y-axis')
                .call(yAxis);

            //style y-axis text
            yAxisElement.selectAll('text')
                .attr('font-size', 14);
            }

        }
//export the BubbleChart class
export default BubbleChart;
